CREATE TABLE PORT(PortId char(1) CHECK (PortId in('C','Q','S')) primary key,
		PortName varchar NOT null,
		Country varchar NOT NULL);

CREATE TABLE PASSENGER(PassengerId int primary key,
		Name varchar not null,
		Sex varchar not null,
		Age int,
		Survived int CHECK (Survived in (0,1)),
		PClass int CHECK (PClass in (2,1,3)),
		PortId char(1),
		foreign key (PortId) references PORT(PortId));
		
CREATE TABLE OCCUPATION(PassengerId int,
			foreign key (PassengerId) references PASSENGER(PassengerId),
			CabinCode varchar not null,
			primary key(PassengerId,CabinCode));
			
CREATE TABLE SERVICE(PassengerId_Dom int,
		foreign key (PassengerId_Dom) references PASSENGER(PassengerId),
		PassengerId_Emp int not null,
		foreign key (PassengerId_Emp) references PASSENGER(PassengerId),
		Role varchar not null,
		primary key (PassengerId_Dom));

CREATE TABLE CATEGORY(LifeBoatCat varchar primary key CHECK (LifeBoatCat in('standard','secours','radeau')),
		Structure varchar not null CHECK (Structure in('bois','bois et toile')),
		Places int not null);
		
CREATE TABLE LIFEBOAT(LifeBoatId varchar primary key ,
		LifeBoatCat varchar,
		foreign key (LifeBoatCat) references CATEGORY(LifeBoatCat),
		Side varchar not null CHECK (Side in('babord','tribord')),
		Position varchar not null CHECK (Position in('avant','arriere')),
		Location varchar DEFAULT 'pont',
		Launching_Time time not null);
		
CREATE TABLE RECOVERY(LifeBoatId varchar,
		foreign key (LifeBoatId) references LIFEBOAT(LifeBoatId),
		Recovery_Time time not null,
		primary key (LifeBoatId));
		
CREATE TABLE RESCUE(PassengerId int,
		foreign key (PassengerId) references PASSENGER(PassengerId),
		LifeBoatId varchar not null,
		foreign key (LifeBoatId) references LIFEBOAT(LifeBoatId),
		primary key(PassengerId));

		

		
				
