SELECT p.PassengerId, Name, Sex, Age, PortId , CabinCode 
from PASSENGER p, OCCUPATION o
where p.PassengerId = o.PassengerId
and p.PassengerId=916;

select Name, Role 
from PASSENGER p, SERVICE s
where s.PassengerId_Dom=p.PassengerId
and s.PassengerId_Emp=1264;

select Name,r.PassengerId 
from RESCUE r,passenger p
where LifeBoatId='7' and r.passengerId=p.passengerId;


