/* Le nombre de passagers par classe et les survivants par classe */
SELECT count(*) FROM PASSENGER WHERE Pclass=1; /* 323 */
SELECT count(*) FROM PASSENGER WHERE Survived = 1 AND Pclass=1; /*200*/
SELECT count(*) FROM PASSENGER WHERE Pclass=2; /*277*/
SELECT count(*) FROM PASSENGER WHERE Survived = 1 AND Pclass=2;/*119*/
SELECT count(*) FROM PASSENGER WHERE Pclass=3;/*709*/
SELECT count(*) FROM PASSENGER WHERE Survived = 1 AND Pclass=3;/*181*/

/* Le nombre de passagers, de survivants et de morts */
SELECT count(*) FROM PASSENGER p;/*1309*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1;/*500*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 0;/*809*/
SELECT count(*) FROM PASSENGER p WHERE Age is NULL;/*263*/

/* Le nombre de passagers selon la catégorie (femme, homme, enfant); */
SELECT count(*) FROM PASSENGER p WHERE Age <= 12;/*94*//*110*/
SELECT count(*) FROM PASSENGER p WHERE Age > 12 AND Sex = 'male';/*608*//*783*/
SELECT count(*) FROM PASSENGER p WHERE Age > 12 AND Sex = 'female';/*344*//*416*/
/* Le nombre de passagers qui ont survecu selon la catégorie (femme, homme, enfant); */
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age <= 12;/*54*//*57*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age > 12 AND Sex = 'male';/*108*//*131*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age > 12 AND Sex = 'female';/*265*//*312*/
/* Le nombre de passagers qui sont morts selon la catégorie (femme, homme, enfant); */
SELECT count(*) FROM PASSENGER p WHERE Survived = 0 AND Age <= 12;/*40*//*53*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 0 AND Age > 12 AND Sex = 'male';/*500*//*652*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 0 AND Age > 12 AND Sex = 'female';/*79*//*104*/

/* Passager par classe et catégorie */
SELECT count(*) FROM PASSENGER p WHERE Age <= 12 AND Pclass=1;/*5*/
SELECT count(*) FROM PASSENGER p WHERE Age > 12 AND Sex = 'male'AND Pclass=1;/*175*/
SELECT count(*) FROM PASSENGER p WHERE Age > 12 AND Sex = 'female' AND Pclass=1;/*143*/
/**/
SELECT count(*) FROM PASSENGER p WHERE Age <= 12 AND Pclass=2;/*24*/
SELECT count(*) FROM PASSENGER p WHERE Age > 12 AND Sex = 'male'AND Pclass=2;/*160*/
SELECT count(*) FROM PASSENGER p WHERE Age > 12 AND Sex = 'female' AND Pclass=2;/*93*/
/**/
SELECT count(*) FROM PASSENGER p WHERE Age <= 12 AND Pclass=3;/*81*/
SELECT count(*) FROM PASSENGER p WHERE Age > 12 AND Sex = 'male'AND Pclass=3;/*448*/
SELECT count(*) FROM PASSENGER p WHERE Age > 12 AND Sex = 'female' AND Pclass=3;/*180*/

/* Survivants par classe et catégorie */
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age <= 12 AND Pclass=1;/*4*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age > 12 AND Sex = 'male'AND Pclass=1;/*57*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age > 12 AND Sex = 'female' AND Pclass=1;/*139*/
/**/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age <= 12 AND Pclass=2;/*24*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age > 12 AND Sex = 'male'AND Pclass=2;/*14*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age > 12 AND Sex = 'female' AND Pclass=2;/*81*/
/**/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age <= 12 AND Pclass=3;/*29*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age > 12 AND Sex = 'male'AND Pclass=3;/*60*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND Age > 12 AND Sex = 'female' AND Pclass=3;/*92*/

/* Le nombre d'enfants rescapés */
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age <= 12);/*56*/
/* Survivants enfants rescapés */
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age <= 12 AND Survived = 1);/*56*/
/* Survivants enfants rescapés par classe*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age <= 12 AND Survived = 1 AND pClass =1);/*4*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age <= 12 AND Survived = 1 AND pClass =2);/*24*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age <= 12 AND Survived = 1 AND pClass =3);/*28*/

/*Le nombre de rescapés */
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p);/*490*/
/* homme et femme rescapés */
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Sex = 'male');/*142*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Sex = 'female');/*292*/
/* Survivants homme et femme rescapés*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Survived = 1 AND Sex = 'male');/*127*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Survived = 1 AND Sex = 'female');/*290*/
/* Survivants hommes rescapés par classe*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Survived = 1 AND pClass =1 AND Sex = 'male');/*56*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Survived = 1 AND pClass =2 AND Sex = 'male');/*14*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Survived = 1 AND pClass =3 AND Sex = 'male');/*57*/
/* Survivants femmes rescapés par classe*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Survived = 1 AND pClass =1 AND Sex = 'female');/*135*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Survived = 1 AND pClass =2 AND Sex = 'female');/*73*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Age > 12 AND Survived = 1 AND pClass =3 AND Sex = 'female');/*82*/

/*Le nombre de rescapés et survivants par embarcation*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Survived = 1 AND PortId = 'C');/*143*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Survived = 1 AND PortId = 'S');/*289*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE Survived = 1 AND PortId = 'Q');/*39*/
/*Le nombre de rescapés par embarcation*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE PortId = 'C');/*147*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE PortId = 'S');/*301*/
SELECT count(*) FROM RESCUE r WHERE r.PassengerId IN( SELECT PassengerId FROM PASSENGER p WHERE PortId = 'Q');/*40*/
/*Le nombre de survivants par embarcation*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND PortId = 'C';/*150*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND PortId = 'S';/*304*/
SELECT count(*) FROM PASSENGER p WHERE Survived = 1 AND PortId = 'Q';/*44*/
/*Le nombre de passagers par embarcation*/
SELECT count(*) FROM PASSENGER p WHERE PortId = 'C';/*270*/
SELECT count(*) FROM PASSENGER p WHERE PortId = 'S';/*914*/
SELECT count(*) FROM PASSENGER p WHERE PortId = 'Q';/*123*/






