 //* On test les valeurs(Portname,country) qui doivent renseignées *// 
INSERT into PORT VALUES('C',null,null);
//* attendu:
ERROR:  null value in column "portname" of relation "port" violates not-null constraint
DETAIL:  Failing row contains (C, null, null).*//

//* PortId doit prendre le valeur de 'C','S' ou 'Q' *//
INSERT into PORT VALUES('L','port','pays');
//* attendu:
ERROR:  new row for relation "port" violates check constraint "port_portid_check"
DETAIL:  Failing row contains (L, port, pays). *//

//* On test les valeurs(name,sex) qui doivent renseignées *//
INSERT into PASSENGER VALUES(2,null,null,14,1,3,'C');
//*attendu:
 ERROR:  null value in column "name" of relation "passenger" violates not-null constraint
DETAIL:  Failing row contains (2, null, null, 14, 1, 3, C). *//

//* Survived doit prendre le valeur de 1 ou 0 *//
INSERT into PASSENGER VALUES(2,'Sarah','M',14,2,3,'C');
//*attendu:
ERROR:  new row for relation "passenger" violates check constraint "passenger_survived_check"
DETAIL:  Failing row contains (2, Sarah, M, 14, 2, 3, C).*//
 
//* inserer *//
INSERT into PORT VALUES('C','port','pays');
//* attendu:
INSERT 0 1 *//


//* PClass doit prendre la valeur de 1,2 ou 3 *//
INSERT into PASSENGER VALUES(2,'Sarah','M',14,1,4,'C');
//*attendu:
ERROR:  new row for relation "passenger" violates check constraint "passenger_pclass_check"
DETAIL:  Failing row contains (2, Sarah, M, 14, 1, 4, C). *//

//* On test si age peut être null *//
INSERT into PASSENGER VALUES(2,'Sarah','M',null,1,3,'C');
//* attendu:
INSERT 0 1 *//

//* On test la valeur(passengerId) qui doit renseignée *//
INSERT INTO OCCUPATION VALUES(null,'B57');
//* attendu:
ERROR:  null value in column "passengerid" of relation "occupation" violates not-null constraint
DETAIL:  Failing row contains (null, B57).
 *//

//* On test la valeur(cabinecode) doit etre renseignée car c'est une clé primaire *//
INSERT INTO OCCUPATION VALUES(2,null);
//* attendu:
ERROR:  null value in column "cabincode" of relation "occupation" violates not-null constraint
DETAIL:  Failing row contains (2, null). *//

//* On test les valeurs(PassengerId_Emp, Role) qui doivent etre renseignées *//
INSERT INTO SERVICE VALUES(5,null,null);
//* attendu:
ERROR:  null value in column "passengerid_emp" of relation "service" violates not-null constraint
DETAIL:  Failing row contains (5, null, null). *//

//* On test les valeurs(Structure, Places ) qui doivent etre renseignées *//
INSERT INTO  CATEGORY VALUES('standard',null,null);
//* attendu:
ERROR:  null value in column "structure" of relation "category" violates not-null constraint
DETAIL:  Failing row contains (standard, null, null).*//

//* LifeBoatCat doit prendre la valeur de standard, secours ou radeau *//
INSERT into CATEGORY VALUES('TORTUE','bois',7);
//* attendu:
ERROR:  new row for relation "category" violates check constraint "category_lifeboatcat_check"
DETAIL:  Failing row contains (TORTUE, bois, 7). *//

//*  structure doit prendre la valeur de bois ou bois et toile *//
INSERT into CATEGORY VALUES('standard','tortue',7);
//* attendu:
ERROR:  new row for relation "category" violates check constraint "category_structure_check"
DETAIL:  Failing row contains (standard, tortue, 7). *//

//* insert *//
INSERT into CATEGORY VALUES('standard','bois',7);
//* attendu:
INSERT 0 1 *//


//*  side doit prendre la valeur de babord ou tribord *//
INSERT into LIFEBOAT VALUES('1','standard','tortue','avant','pont','01:10:00');
//* attendu:
ERROR:  new row for relation "lifeboat" violates check constraint "lifeboat_side_check"
DETAIL:  Failing row contains (1, standard, tortue, avant, pont, 01:10:00).
 *//

//*  Postition doit prendre la valeur de avant ou arriere *//
INSERT into LIFEBOAT VALUES('1','standard','tribord','tortue','pont','01:10:00');
//* attendu:
ERROR:  new row for relation "lifeboat" violates check constraint "lifeboat_position_check"
DETAIL:  Failing row contains (1, standard, tribord, tortue, pont, 01:10:00). *//

//*  Location doit prendre la valeur pont donc il y'a une insertion *//
INSERT into LIFEBOAT VALUES('2','standard','tribord','avant',null,'01:10:00');
//* attendu:
INSERT 0 1 *//

//*  On test les valeurs(side,position,location,launching_time) qui doivent etre renseignées *//
INSERT into LIFEBOAT VALUES('1',null,null,null,null);
//*attendu:
 ERROR:  null value in column "side" of relation "lifeboat" violates not-null constraint
DETAIL:  Failing row contains (1, null, null, null, null, null). *//

//*  On test la valeur(Recovery_time) qui doit etre renseignée *//
INSERT into RECOVERY VALUES('1',NULL);
//* attendu:
ERROR:  null value in column "recovery_time" of relation "recovery" violates not-null constraint
DETAIL:  Failing row contains (1, null).*//

//*  On test la valeur(Rescue) qui doit etre renseignée *//
INSERT into RESCUE VALUES(2,NULL);
//* attendu:
ERROR:  null value in column "lifeboatid" of relation "rescue" violates not-null constraint
DETAIL:  Failing row contains (2, null).*//

//* PassengerId est une clé etrangère faisant référence a la cle primaire PassengerId (PASSENGER) mais 48 n'existe pas dans PASSENGER *//
INSERT INTO OCCUPATION VALUES(48,'B57');
//* attendu:
ERROR:  insert or update on table "occupation" violates foreign key constraint "occupation_passengerid_fkey"
DETAIL:  Key (passengerid)=(48) is not present in table "passenger".*//


