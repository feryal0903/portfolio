import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Classification {


    private static ArrayList<Depeche> lectureDepeches(String nomFichier) {
        //creation d'un tableau de dépêches
        ArrayList<Depeche> depeches = new ArrayList<>();
        try {
            // lecture du fichier d'entrée
            FileInputStream file = new FileInputStream(nomFichier);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String ligne = scanner.nextLine();
                String id = ligne.substring(3);
                ligne = scanner.nextLine();
                String date = ligne.substring(3);
                ligne = scanner.nextLine();
                String categorie = ligne.substring(3);
                ligne = scanner.nextLine();
                String lignes = ligne.substring(3);
                while (scanner.hasNextLine() && !ligne.equals("")) {
                    ligne = scanner.nextLine();
                    if (!ligne.equals("")) {
                        lignes = lignes + '\n' + ligne;
                    }
                }
                Depeche uneDepeche = new Depeche(id, date, categorie, lignes);
                depeches.add(uneDepeche);
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return depeches;
    }


    public static void classementDepeches(ArrayList<Depeche> depeches, ArrayList<Categorie> categories, String nomFichier) {
        ArrayList<PaireChaineEntier> res = new ArrayList<>();
        ArrayList<PaireChaineEntier> res2 = new ArrayList<>();
        ArrayList<String> test = new ArrayList<>();
        for(int i=0;i<depeches.size();i++){
            for(int y=0;y<categories.size();y++){
                int ent=categories.get(y).score(depeches.get(i));
                PaireChaineEntier pce=new PaireChaineEntier(categories.get(y).getNom(),ent);
                res.add(pce);
            }
            String max=UtilitairePaireChaineEntier.chaineMax(res);
            test.add(max);
            res.clear();
        }
        try {
            FileWriter file = new FileWriter(nomFichier);
            for (int i = 0; i < test.size(); i++) {
                String dep = test.get(i);
                String str = String.valueOf(i + 1);
                file.write(str + " : " + dep + "\n");
            }
            /*for (int y = 0; y < categories.size(); y++) {
                PaireChaineEntier ch = new PaireChaineEntier(categories.get(y).getNom(), 0);
                res.add(ch);
            }*/

            int cptcul=0;
            int cptspo=0;
            int cptpol=0;
            int cptsc=0;
            int cpteco=0;
            for (int i = 0; i < depeches.size(); i++) {
                if(depeches.get(i).getCategorie().compareToIgnoreCase(test.get(i))==0 && test.get(i).equals("culture")) {
                    cptcul = cptcul + 1;
                }if (depeches.get(i).getCategorie().compareToIgnoreCase(test.get(i))==0 && test.get(i).equals("sports")) {
                    cptspo = cptspo + 1;
                }if (depeches.get(i).getCategorie().compareToIgnoreCase(test.get(i))==0 && test.get(i).equals("economie")) {
                    cpteco = cpteco + 1;
                } if(depeches.get(i).getCategorie().compareToIgnoreCase(test.get(i))==0 && test.get(i).equals("politique")) {
                    cptpol = cptpol + 1;
                }if (depeches.get(i).getCategorie().compareToIgnoreCase(test.get(i))==0 && test.get(i).equals("environnement-sciences")){
                    cptsc = cptsc + 1;
                }

                /*if (depeches.get(i).getCategorie().compareToIgnoreCase(test.get(i)) == 0&& UtilitairePaireChaineEntier.indicePourChaine(res, depeches.get(i).getCategorie())!=-1) {
                    int x = UtilitairePaireChaineEntier.indicePourChaine(res, depeches.get(i).getCategorie());
                    res.set(x, new PaireChaineEntier(res.get(x).getChaine(), res.get(x).getEntier() + 1));
                }*/


            }
            /*for (int y = 0; y < categories.size(); y++) {
                PaireChaineEntier ch = new PaireChaineEntier(categories.get(y).getNom(), 0);
                res2.add(ch);
            }*/
            int cptcul1=0;
            int cptspo1=0;
            int cptpol1=0;
            int cptsc1=0;
            int cpteco1=0;
            for (int i = 0; i < test.size(); i++) {
                if (test.get(i).equals("culture")) {
                    cptcul1 = cptcul1 + 1;
                } if ( test.get(i).equals("sports")) {
                    cptspo1 = cptspo1 + 1;
                } if (test.get(i).equals("economie")) {
                    cpteco1 = cpteco1 + 1;
                } if (test.get(i).equals("politique")) {
                    cptpol1 = cptpol1 + 1;
                } if (test.get(i).equals("environnement-sciences")){
                    cptsc1 = cptsc1 + 1;
                }
                /*if (UtilitairePaireChaineEntier.indicePourChaine(res, depeches.get(i).getCategorie())!=-1) {
                    int x = UtilitairePaireChaineEntier.indicePourChaine(res, depeches.get(i).getCategorie());
                    res2.set(x, new PaireChaineEntier(res.get(x).getChaine(), res.get(x).getEntier() + 1));
                }*/

            }
            /*int prccul=(res.get(1).getEntier()*100)/res2.get(1).getEntier();
            int prcspo=(res.get(4).getEntier()*100)/res2.get(4).getEntier();
            int prcpol=(res.get(3).getEntier()*100)/res2.get(3).getEntier();
            int prcsc=(res.get(0).getEntier()*100)/res2.get(0).getEntier();
            int prceco=(res.get(2).getEntier()*100)/res2.get(2).getEntier();*/

            int prccul=(cptcul*100)/cptcul1;
            int prcspo=(cptspo*100)/cptspo1;
            int prcpol=(cptpol*100)/cptpol1;
            int prcsc=(cptsc*100)/cptsc1;
            int prceco=(cpteco*100)/cpteco1;
            file.write("culture" + " : " + prccul+" %"+"\n");
            file.write("sports" + " : " + prcspo+" %"+"\n");
            file.write("economie" + " : " + prceco+" %"+"\n");
            file.write("politique" + " : " + prcpol+" %"+"\n");
            file.write("environnement-sciences" + " : " + prcsc+" %"+"\n");
            float moy=(prccul+prceco+prcpol+prcsc+prcspo)/5;
            file.write("moyenne" + " : " + moy+" %"+"\n");
            file.close();

            } catch(IOException e) {
            e.printStackTrace();
            }
        }

    public static ArrayList<PaireChaineEntier> initDico(ArrayList<Depeche> depeches, String categorie) {
        ArrayList<PaireChaineEntier> resultat = new ArrayList<>();
        ArrayList<String> s=new ArrayList<>();
        for(int i=0;i<depeches.size();i++){
            if(depeches.get(i).getCategorie().compareToIgnoreCase(categorie)==0){
                for(int y=0;y<depeches.get(i).getMots().size();y++) {
                    PaireChaineEntier p = new PaireChaineEntier(depeches.get(i).getMots().get(y),0);
                    s.add(depeches.get(i).getMots().get(y));
                    int j=0;
                    boolean c=true;
                    while(j<s.size() && c ){
                        if (s.get(j).compareToIgnoreCase(p.getChaine())==0){
                            c=false;

                        }j++;

                    }if(j==s.size()){ resultat.add(p);}
                }
            }

        }
        return resultat;

    }

    public static void calculScores(ArrayList<Depeche> depeches, String categorie, ArrayList<PaireChaineEntier> dictionnaire) {
        for(int  i=0;i<depeches.size();i++){
            if(depeches.get(i).getCategorie().compareToIgnoreCase(categorie)==0){
                for(int y=0;y<depeches.get(i).getMots().size();y++){
                    if(UtilitairePaireChaineEntier.indicePourChaine(dictionnaire,depeches.get(i).getMots().get(y))>=0){
                        int ind=UtilitairePaireChaineEntier.indicePourChaine(dictionnaire,depeches.get(i).getMots().get(y));
                        dictionnaire.set(ind, new PaireChaineEntier(dictionnaire.get(ind).getChaine(), dictionnaire.get(ind).getEntier() + 1));
                    }
                }

            }if(depeches.get(i).getCategorie().compareToIgnoreCase(categorie)!=0) {
                for (int y = 0; y < depeches.get(i).getMots().size(); y++) {
                    if (UtilitairePaireChaineEntier.indicePourChaine(dictionnaire, depeches.get(i).getMots().get(y)) >= 0) {
                        int ind = UtilitairePaireChaineEntier.indicePourChaine(dictionnaire, depeches.get(i).getMots().get(y));
                        dictionnaire.set(ind, new PaireChaineEntier(dictionnaire.get(ind).getChaine(), dictionnaire.get(ind).getEntier() - 1));
                    }
                }
            }
        }
    }

    public static int poidsPourScore(int score) {
        int res=0;
        if(score <= -400 ){
            res=1;
        }else if(score <-200){
            res=2;
        }else{
            res=3;
        }
        return res;
    }

    public static void generationLexique(ArrayList<Depeche> depeches, String categorie, String nomFichier) {
        ArrayList<PaireChaineEntier>res=new ArrayList<>();
        res=initDico(depeches,categorie);
        calculScores(depeches,categorie,res);
        for(int i=0;i<res.size();i++){
            res.set(i,new PaireChaineEntier(res.get(i).getChaine(),poidsPourScore(res.get(i).getEntier())));
        }
        try {
            FileWriter file = new FileWriter(nomFichier);
            for(int y=0;y<res.size();y++){
                file.write(res.get(y).getChaine()+":"+res.get(y).getEntier()+ "\n");
            }
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {

        //Chargement des dépêches en mémoire

        long startTime = System.currentTimeMillis();
        ArrayList<Depeche> depeches = lectureDepeches("./test.txt");
        //for (int i = 0; i < depeches.size(); i++) {
        //    depeches.get(i).afficher();
        //}
        Categorie culture =new Categorie("culture");
        Categorie sports =new Categorie("sports");
        Categorie politique =new Categorie("politique");
        Categorie economie =new Categorie("economie");
        Categorie environnement =new Categorie("environnement-sciences");
        ArrayList<Categorie> cat=new ArrayList<>(Arrays.asList(environnement,culture,economie,politique,sports));
        long endTime = System.currentTimeMillis();
        System.out.println("Initialisation catégorie : " + (endTime-startTime) + "ms");

        startTime = System.currentTimeMillis();
        generationLexique(depeches,"culture","./lexique_culture.txt");
        generationLexique(depeches,"sports","./lexique_sports.txt");
        generationLexique(depeches,"economie","./lexique_economie.txt");
        generationLexique(depeches,"politique","./lexique_politique.txt");
        generationLexique(depeches,"environnement-sciences","./lexique_environnement-sciences.txt");
        endTime = System.currentTimeMillis();
        System.out.println("Génération des lexiques : " + (endTime-startTime) + "ms");

        startTime = System.currentTimeMillis();
        culture.initLexique("./lexique_culture.txt");
        sports.initLexique("./lexique_sports.txt");
        politique.initLexique("./lexique_politique.txt");
        economie.initLexique("./lexique_economie.txt");
        environnement.initLexique("./lexique_environnement-sciences.txt");
        endTime = System.currentTimeMillis();
        System.out.println("Crée les lexiques : " + (endTime-startTime) + "ms");

        classementDepeches(depeches,cat,"./classement.txt");





    }


}

