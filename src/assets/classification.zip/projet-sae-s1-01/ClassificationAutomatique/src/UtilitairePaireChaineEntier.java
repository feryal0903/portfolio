import java.util.ArrayList;

public class UtilitairePaireChaineEntier {


    public static int indicePourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        int i=0;
        while(i<listePaires.size()-1){
            if(listePaires.get(i).getChaine().compareToIgnoreCase(chaine)==0){
                return i;
            }else{
                i++;
            }
        }
        return -1;

    }

    public static int entierPourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        int i=0;
        while(i<listePaires.size()-1){
            if(listePaires.get(i).getChaine().compareTo(chaine)==0){
                return listePaires.get(i).getEntier();
            }else{
                i++;
            }
        }
        return 0;
    }

    public static String chaineMax(ArrayList<PaireChaineEntier> listePaires) {
        int max = listePaires.get(0).getEntier();
        String chaine=listePaires.get(0).getChaine();
        for (int i = 0; i < listePaires.size(); i++) {
            if (listePaires.get(i).getEntier() > max) {
                chaine=listePaires.get(i).getChaine();
            }
        }return chaine;
    }


    public static float moyenne(ArrayList<PaireChaineEntier> listePaires) {
        float s=0;
        for(int i=0;i<listePaires.size();i++){
            s=s+listePaires.get(i).getEntier();
        }return s/listePaires.size();
    }

}
